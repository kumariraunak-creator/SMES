# Smart Matrimonial & Event Service Platform

**Presentation-ready visual refresh:** responsive layout, vibrant plum/berry/coral gradients, polished profile and vendor cards, animated hero decorations, improved buttons, modals, and mobile styling.

A full-stack, responsive matrimonial and wedding vendor booking application using Node.js, Express, MongoDB Atlas, Mongoose, JWT and bcrypt.

## Included features
- User registration and login (passwords hashed with bcrypt; JWT sessions)
- User profile creation at registration and profile browsing/search by city, age and profile type
- Profile data and vendor data stored in MongoDB
- Vendor directory with category and city filters
- Authenticated vendor booking requests and booking history/cancellation
- Review API, restricted to users with an accepted booking
- First-run seed data for fictional sample profiles and wedding vendors
- Responsive frontend served by the Express backend
- Health check at `/api/health`

## Run locally (Windows / Antigravity / VS Code)
1. Extract the ZIP and open the **smart-matrimonial-fullstack** folder.
2. Open a terminal in this folder (the folder that contains `server.js` and `package.json`).
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Open `.env` and set `MONGO_URI` to the complete connection string copied from MongoDB Atlas. Replace the username, password, and cluster host placeholders. URL-encode special characters in the database password. Set a long random `JWT_SECRET`.
6. In MongoDB Atlas, check that the database user exists and Network Access permits the server's IP. For local development, adding `0.0.0.0/0` allows access from any IP and is less secure; use only temporarily if needed, then restrict it.
7. Run `npm start`.
8. Open `http://localhost:5000`. Test `http://localhost:5000/api/health`.

Do not run `cd backend` if the terminal is already inside the `backend` folder. In this package, run commands in the project root.

## Deploy as one web service on Render
1. Push this project to a GitHub repository.
2. Create a new **Web Service** on Render and connect that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add environment variables in Render: `MONGO_URI`, `JWT_SECRET`, `NODE_ENV=production`, `CLIENT_URL` set to the Render service URL (or omit it if not needed).
6. Make sure Atlas Network Access allows the deployed service to connect. Test `/api/health` and then the homepage.

## Important security notes
- Never commit `.env` or publish database credentials.
- A MongoDB password previously pasted into a chat should be rotated in Atlas before deploying. Put the new password only in your local `.env` and Render environment variables.
- Seed profiles and vendors are fictional demo records.
- Real interest requests, messaging, profile-photo upload, vendor-owner dashboard, admin dashboard and payment integration are not implemented in this version. The booking and authentication paths are connected to the database.
