const mongoose = require('mongoose');
const bookingSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  vendor: { type: mongoose.Schema.Types.ObjectId, ref: 'Vendor', required: true },
  eventDate: { type: Date, required: true },
  message: { type: String, default: '', maxlength: 1000 },
  status: { type: String, enum: ['Pending', 'Accepted', 'Rejected', 'Cancelled'], default: 'Pending' }
}, { timestamps: true });
module.exports = mongoose.model('Booking', bookingSchema);
