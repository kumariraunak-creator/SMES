const mongoose = require('mongoose');
const profileSchema = new mongoose.Schema({
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, unique: true },
  displayName: { type: String, required: true, trim: true, maxlength: 80 },
  age: { type: Number, required: true, min: 18, max: 100 },
  gender: { type: String, enum: ['Bride', 'Groom', 'Other'], required: true },
  city: { type: String, required: true, trim: true },
  profession: { type: String, default: '', maxlength: 100 },
  education: { type: String, default: '', maxlength: 100 },
  about: { type: String, default: '', maxlength: 1000 },
  interests: [{ type: String, maxlength: 40 }],
  photoUrl: { type: String, default: '' },
  isVisible: { type: Boolean, default: true }
}, { timestamps: true });
module.exports = mongoose.model('Profile', profileSchema);
