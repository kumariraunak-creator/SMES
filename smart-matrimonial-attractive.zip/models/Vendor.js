const mongoose = require('mongoose');
const vendorSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  category: { type: String, enum: ['Venue', 'Photography', 'Decor', 'Catering', 'Makeup', 'Planning', 'Other'], required: true },
  city: { type: String, required: true, trim: true },
  description: { type: String, default: '' },
  priceFrom: { type: Number, min: 0, default: 0 },
  imageUrl: { type: String, default: '' },
  contactEmail: { type: String, default: '' },
  owner: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  active: { type: Boolean, default: true }
}, { timestamps: true });
module.exports = mongoose.model('Vendor', vendorSchema);
