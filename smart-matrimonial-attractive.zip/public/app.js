const $ = s => document.querySelector(s);
let token = localStorage.getItem('smh_token') || '';
let currentUser = JSON.parse(localStorage.getItem('smh_user') || 'null');
let selectedVendor = null;
let authMode = 'register';
const esc = value => String(value ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const money = n => n ? '₹' + Number(n).toLocaleString('en-IN') : 'Contact for price';
let toastTimer;
function toast(msg){$('#toast').textContent=msg;$('#toast').classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>$('#toast').classList.remove('show'),3000)}
async function api(path, options={}) {
  const headers = { 'Content-Type':'application/json', ...(options.headers||{}) };
  if (token) headers.Authorization = `Bearer ${token}`;
  let response;
  try { response = await fetch('/api'+path, {...options, headers}); }
  catch(e){ throw new Error('Cannot reach the server. Start the backend or check your deployment.'); }
  const data = await response.json().catch(()=>({message:'Unexpected server response.'}));
  if (!response.ok) throw new Error(data.message || 'Request failed.');
  return data;
}
function openAuth(mode='register'){
  authMode=mode;$('#authBackdrop').classList.add('open');document.body.style.overflow='hidden';
  $('#authMessage').textContent='';$('#authForm').reset();
  const registering=mode==='register';
  $('#authKicker').textContent=registering?'YOUR STORY STARTS HERE':'WELCOME BACK';
  $('#authTitle').innerHTML=registering?'Create your <em>profile</em>':'Log in to your <em>journey</em>';
  $('#authDescription').textContent=registering?'Register to manage your profile and request vendor bookings.':'Sign in to manage your profile and view your bookings.';
  $('#nameField').classList.toggle('hidden',!registering);$('#registerFields').classList.toggle('hidden',!registering);
  ['nameInput','ageInput','registerCity','profileGender'].forEach(id=>{const el=$('#'+id);if(el)el.required=registering});
  $('#authSubmit').textContent=registering?'Create account →':'Log in →';
  $('#switchAuth').innerHTML=registering?'Already have an account? <button type="button" id="switchToLogin">Log in</button>':'New here? <button type="button" id="switchToRegister">Create an account</button>';
  $('#switchToLogin')?.addEventListener('click',()=>openAuth('login'));
  $('#switchToRegister')?.addEventListener('click',()=>openAuth('register'));
}
function closeAuth(){$('#authBackdrop').classList.remove('open');document.body.style.overflow=''}
$('#registerOpen').onclick=()=>openAuth('register');$('#heroRegister').onclick=()=>openAuth('register');$('#ctaRegister').onclick=()=>openAuth('register');$('#loginOpen').onclick=()=>openAuth('login');
$('#closeModal').onclick=closeAuth;$('#authBackdrop').addEventListener('click',e=>{if(e.target.id==='authBackdrop')closeAuth()});
$('#authForm').addEventListener('submit',async e=>{
 e.preventDefault();$('#authSubmit').disabled=true;$('#authMessage').textContent='Please wait…';
 try{
  const body={email:$('#emailInput').value.trim(),password:$('#passwordInput').value};
  if(authMode==='register')Object.assign(body,{name:$('#nameInput').value.trim(),age:Number($('#ageInput').value),gender:$('#profileGender').value,city:$('#registerCity').value.trim()});
  const data=await api('/auth/'+authMode,{method:'POST',body:JSON.stringify(body)});
  token=data.token;currentUser=data.user;localStorage.setItem('smh_token',token);localStorage.setItem('smh_user',JSON.stringify(currentUser));
  closeAuth();updateSession();await loadBookings();toast(data.message||'Success!');
 }catch(err){$('#authMessage').textContent=err.message}finally{$('#authSubmit').disabled=false}
});
function updateSession(){
 const logged=Boolean(token&&currentUser);
 $('#loginOpen').classList.toggle('hidden',logged);$('#registerOpen').classList.toggle('hidden',logged);$('#logoutBtn').classList.toggle('hidden',!logged);
}
$('#logoutBtn').onclick=()=>{token='';currentUser=null;localStorage.removeItem('smh_token');localStorage.removeItem('smh_user');updateSession();$('#bookingList').innerHTML='<div class="empty">Log in to view your bookings.</div>';toast('You have logged out.')};

async function loadProfiles(filters={}){
 $('#profileGrid').innerHTML='<div class="loading">Finding profiles…</div>';
 const qs=new URLSearchParams();Object.entries(filters).forEach(([k,v])=>{if(v!==''&&v!=null)qs.set(k,v)});
 try{
  const data=await api('/profiles'+(qs.toString()?'?'+qs.toString():''));
  $('#profileCount').textContent=`${data.profiles.length} profile${data.profiles.length===1?'':'s'} found`;
  if(!data.profiles.length){$('#profileGrid').innerHTML='<div class="empty">No profiles match those preferences. Try changing the filters.</div>';return}
  $('#profileGrid').innerHTML=data.profiles.map(p=>`<article class="profile-card"><img src="${esc(p.photoUrl||'https://images.unsplash.com/photo-1517841905240-472988babdf9?auto=format&fit=crop&w=600&q=80')}" alt="Profile photo" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80'"><div class="profile-info"><div class="profile-name">${esc(p.displayName)} <span class="verified">✓</span></div><p>${esc(p.age)} · ${esc(p.gender)} · ${esc(p.city)}</p><p>${esc(p.profession||'Profession not added')}</p><div class="tags">${(p.interests||[]).slice(0,3).map(t=>`<span>${esc(t)}</span>`).join('')}</div><p>${esc((p.about||'').slice(0,105))}${(p.about||'').length>105?'…':''}</p><div class="profile-actions"><button class="btn btn-outline" data-profile="${esc(p._id)}">View details</button><button class="btn interest" data-interest="${esc(p.displayName)}">♡ Show interest</button></div></div></article>`).join('');
  document.querySelectorAll('[data-profile]').forEach(btn=>btn.onclick=()=>{const p=data.profiles.find(x=>x._id===btn.dataset.profile);alert(`${p.displayName}\\nAge: ${p.age}\\n${p.gender} · ${p.city}\\n${p.profession||''}\\nEducation: ${p.education||'Not specified'}\\n\\n${p.about||'No introduction added.'}\\n\\nInterests: ${(p.interests||[]).join(', ')||'Not added'}`)});
  document.querySelectorAll('[data-interest]').forEach(btn=>btn.onclick=()=>{if(!token)return openAuth('login');toast(`Interest action for ${btn.dataset.interest} is a demo. A consent-based interest API can be added next.`)});
 }catch(err){$('#profileCount').textContent='Could not load profiles';$('#profileGrid').innerHTML=`<div class="empty">${esc(err.message)}<br><br>Check that the server is running and MongoDB is connected.</div>`}
}
$('#searchProfiles').onclick=()=>loadProfiles({gender:$('#genderFilter').value,minAge:$('#minAge').value,maxAge:$('#maxAge').value,city:$('#cityFilter').value.trim()});
$('#refreshProfiles').onclick=()=>loadProfiles();
async function loadVendors(){
 $('#vendorGrid').innerHTML='<div class="loading">Loading wedding services…</div>';
 const qs=new URLSearchParams();if($('#vendorCategory').value)qs.set('category',$('#vendorCategory').value);if($('#vendorCity').value.trim())qs.set('city',$('#vendorCity').value.trim());
 try{
  const data=await api('/vendors'+(qs.toString()?'?'+qs.toString():''));
  if(!data.vendors.length){$('#vendorGrid').innerHTML='<div class="empty">No services found. Try a different city or category.</div>';return}
  $('#vendorGrid').innerHTML=data.vendors.map(v=>`<article class="vendor-card"><img src="${esc(v.imageUrl||'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=900&q=80')}" alt="${esc(v.name)}" loading="lazy" onerror="this.src='https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=900&q=80'"><div class="vendor-info"><div class="vendor-top"><h3>${esc(v.name)}</h3><span class="category">${esc(v.category)}</span></div><p>${esc(v.description)}</p><div class="vendor-meta"><span>⌖ ${esc(v.city)}</span><b>${money(v.priceFrom)}</b></div><button class="btn btn-primary" data-book="${esc(v._id)}" data-vendor-name="${esc(v.name)}">Request booking →</button></div></article>`).join('');
  document.querySelectorAll('[data-book]').forEach(btn=>btn.onclick=()=>openBooking(btn.dataset.book,btn.dataset.vendorName));
 }catch(err){$('#vendorGrid').innerHTML=`<div class="empty">${esc(err.message)}</div>`}
}
$('#searchVendors').onclick=loadVendors;
function openBooking(id,name){
 if(!token){openAuth('login');toast('Please log in before requesting a booking.');return}
 selectedVendor=id;$('#bookingVendorName').textContent=`Booking request for ${name}`;$('#bookingMessageStatus').textContent='';
 const d=new Date();d.setDate(d.getDate()+1);$('#eventDate').min=d.toISOString().slice(0,10);$('#eventDate').value='';
 $('#bookingBackdrop').classList.add('open');document.body.style.overflow='hidden';
}
function closeBooking(){$('#bookingBackdrop').classList.remove('open');document.body.style.overflow=''}
$('#closeBooking').onclick=closeBooking;$('#bookingBackdrop').addEventListener('click',e=>{if(e.target.id==='bookingBackdrop')closeBooking()});
$('#bookingForm').addEventListener('submit',async e=>{
 e.preventDefault();try{const data=await api('/bookings',{method:'POST',body:JSON.stringify({vendorId:selectedVendor,eventDate:$('#eventDate').value,message:$('#bookingMessage').value})});closeBooking();toast(data.message);await loadBookings()}catch(err){$('#bookingMessageStatus').textContent=err.message}
});
async function loadBookings(){
 if(!token){$('#bookingList').innerHTML='<div class="empty">Log in to view your bookings.</div>';return}
 try{const data=await api('/bookings/mine');if(!data.bookings.length){$('#bookingList').innerHTML='<div class="empty">No booking requests yet. Explore wedding services above to get started.</div>';return}
 $('#bookingList').innerHTML=data.bookings.map(b=>`<div class="booking-row"><div><b>${esc(b.vendor?.name||'Vendor')}</b><p>${esc(b.vendor?.category||'Service')} · ${new Date(b.eventDate).toLocaleDateString('en-IN')} · ${esc(b.vendor?.city||'')}</p></div><span class="status">${esc(b.status)}</span>${b.status==='Pending'?`<button class="btn btn-outline" data-cancel="${esc(b._id)}">Cancel</button>`:''}</div>`).join('');
 document.querySelectorAll('[data-cancel]').forEach(btn=>btn.onclick=async()=>{try{const result=await api('/bookings/'+btn.dataset.cancel+'/cancel',{method:'PATCH'});toast(result.message);loadBookings()}catch(err){toast(err.message)}});
 }catch(err){$('#bookingList').innerHTML=`<div class="empty">${esc(err.message)}</div>`}
}
$('#menuBtn').onclick=()=>$('#navLinks').classList.toggle('open');
document.querySelectorAll('#navLinks a').forEach(a=>a.addEventListener('click',()=>$('#navLinks').classList.remove('open')));
document.addEventListener('keydown',e=>{if(e.key==='Escape'){closeAuth();closeBooking()}});
async function init(){updateSession();await Promise.all([loadProfiles(),loadVendors()]);await loadBookings()}
init();
