const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Profile = require('../models/Profile');
const { protect } = require('../middleware/auth');
const router = express.Router();

const safeUser = user => ({ id: user._id, name: user.name, email: user.email, role: user.role });
function signToken(user) {
  return jwt.sign({ id: user._id, role: user.role }, process.env.JWT_SECRET, { expiresIn: '7d' });
}

router.post('/register', async (req, res, next) => {
  try {
    const { name, email, password, age, gender, city } = req.body;
    if (!name || !email || !password || !age || !gender || !city)
      return res.status(400).json({ message: 'Name, email, password, age, gender and city are required.' });
    if (String(password).length < 8)
      return res.status(400).json({ message: 'Password must be at least 8 characters.' });
    if (Number(age) < 18)
      return res.status(400).json({ message: 'You must be at least 18 to create a profile.' });
    const normalizedEmail = String(email).toLowerCase().trim();
    if (await User.findOne({ email: normalizedEmail }))
      return res.status(409).json({ message: 'An account with this email already exists.' });
    const hash = await bcrypt.hash(password, 12);
    const user = await User.create({ name: name.trim(), email: normalizedEmail, password: hash });
    await Profile.create({ user: user._id, displayName: name.trim(), age: Number(age), gender, city: city.trim() });
    res.status(201).json({ token: signToken(user), user: safeUser(user), message: 'Account created successfully.' });
  } catch (err) { next(err); }
});

router.post('/login', async (req, res, next) => {
  try {
    const email = String(req.body.email || '').toLowerCase().trim();
    const password = String(req.body.password || '');
    const user = await User.findOne({ email }).select('+password');
    if (!user || !(await bcrypt.compare(password, user.password)))
      return res.status(401).json({ message: 'Incorrect email or password.' });
    res.json({ token: signToken(user), user: safeUser(user), message: 'Welcome back.' });
  } catch (err) { next(err); }
});

router.get('/me', protect, async (req, res) => {
  const profile = await Profile.findOne({ user: req.user._id });
  res.json({ user: safeUser(req.user), profile });
});
module.exports = router;
