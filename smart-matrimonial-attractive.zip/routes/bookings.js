const express = require('express');
const Booking = require('../models/Booking');
const Vendor = require('../models/Vendor');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.post('/', protect, async (req, res, next) => {
  try {
    const { vendorId, eventDate, message } = req.body;
    if (!vendorId || !eventDate) return res.status(400).json({ message: 'Choose a vendor and event date.' });
    const date = new Date(eventDate);
    if (Number.isNaN(date.getTime()) || date < new Date(new Date().toDateString()))
      return res.status(400).json({ message: 'Choose a valid future event date.' });
    const vendor = await Vendor.findOne({ _id: vendorId, active: true });
    if (!vendor) return res.status(404).json({ message: 'Vendor not found.' });
    const booking = await Booking.create({ user: req.user._id, vendor: vendor._id, eventDate: date, message: String(message || '').slice(0, 1000) });
    res.status(201).json({ booking, message: 'Booking request sent.' });
  } catch (err) { next(err); }
});

router.get('/mine', protect, async (req, res, next) => {
  try {
    const bookings = await Booking.find({ user: req.user._id }).populate('vendor', 'name category city priceFrom imageUrl').sort({ createdAt: -1 });
    res.json({ bookings });
  } catch (err) { next(err); }
});

router.patch('/:id/cancel', protect, async (req, res, next) => {
  try {
    const booking = await Booking.findOne({ _id: req.params.id, user: req.user._id });
    if (!booking) return res.status(404).json({ message: 'Booking not found.' });
    if (booking.status !== 'Pending') return res.status(400).json({ message: 'Only pending bookings can be cancelled.' });
    booking.status = 'Cancelled'; await booking.save();
    res.json({ booking, message: 'Booking cancelled.' });
  } catch (err) { next(err); }
});
module.exports = router;
