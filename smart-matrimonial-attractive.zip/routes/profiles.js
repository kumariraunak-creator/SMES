const express = require('express');
const Profile = require('../models/Profile');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const filter = { isVisible: true };
    if (req.query.city) filter.city = new RegExp(String(req.query.city).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    if (req.query.gender && ['Bride', 'Groom', 'Other'].includes(req.query.gender)) filter.gender = req.query.gender;
    if (req.query.minAge || req.query.maxAge) filter.age = {};
    if (req.query.minAge) filter.age.$gte = Math.max(18, Number(req.query.minAge));
    if (req.query.maxAge) filter.age.$lte = Math.min(100, Number(req.query.maxAge));
    const profiles = await Profile.find(filter).select('-user').sort({ createdAt: -1 }).limit(100);
    res.json({ profiles });
  } catch (err) { next(err); }
});

router.get('/mine', protect, async (req, res, next) => {
  try {
    const profile = await Profile.findOne({ user: req.user._id });
    res.json({ profile });
  } catch (err) { next(err); }
});

router.put('/mine', protect, async (req, res, next) => {
  try {
    const allowed = ['displayName', 'age', 'gender', 'city', 'profession', 'education', 'about', 'interests', 'photoUrl', 'isVisible'];
    const update = {};
    for (const key of allowed) if (req.body[key] !== undefined) update[key] = req.body[key];
    if (update.age !== undefined && (Number(update.age) < 18 || Number(update.age) > 100))
      return res.status(400).json({ message: 'Age must be between 18 and 100.' });
    const profile = await Profile.findOneAndUpdate({ user: req.user._id }, update, { new: true, runValidators: true });
    if (!profile) return res.status(404).json({ message: 'Profile not found.' });
    res.json({ profile, message: 'Profile updated.' });
  } catch (err) { next(err); }
});
module.exports = router;
