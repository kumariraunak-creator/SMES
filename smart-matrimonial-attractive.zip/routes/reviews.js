const express = require('express');
const Review = require('../models/Review');
const Vendor = require('../models/Vendor');
const Booking = require('../models/Booking');
const { protect } = require('../middleware/auth');
const router = express.Router();

router.get('/vendor/:vendorId', async (req, res, next) => {
  try {
    const reviews = await Review.find({ vendor: req.params.vendorId }).populate('user', 'name').sort({ createdAt: -1 }).limit(100);
    res.json({ reviews });
  } catch (err) { next(err); }
});

router.post('/', protect, async (req, res, next) => {
  try {
    const { vendorId, rating, comment } = req.body;
    if (!vendorId || !Number.isInteger(Number(rating)) || Number(rating) < 1 || Number(rating) > 5)
      return res.status(400).json({ message: 'Select a vendor and rating from 1 to 5.' });
    const vendor = await Vendor.findOne({ _id: vendorId, active: true });
    if (!vendor) return res.status(404).json({ message: 'Vendor not found.' });
    const completedOrAccepted = await Booking.findOne({ user: req.user._id, vendor: vendorId, status: 'Accepted' });
    if (!completedOrAccepted) return res.status(403).json({ message: 'A review can be added after a vendor accepts your booking.' });
    const review = await Review.findOneAndUpdate(
      { user: req.user._id, vendor: vendorId },
      { rating: Number(rating), comment: String(comment || '').slice(0, 1000) },
      { new: true, upsert: true, runValidators: true, setDefaultsOnInsert: true }
    );
    res.status(201).json({ review, message: 'Review saved.' });
  } catch (err) { next(err); }
});
module.exports = router;
