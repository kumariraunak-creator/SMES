const express = require('express');
const Vendor = require('../models/Vendor');
const Review = require('../models/Review');
const { protect, allowRoles } = require('../middleware/auth');
const router = express.Router();

router.get('/', async (req, res, next) => {
  try {
    const filter = { active: true };
    if (req.query.category) filter.category = req.query.category;
    if (req.query.city) filter.city = new RegExp(String(req.query.city).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'i');
    const vendors = await Vendor.find(filter).select('-owner').sort({ createdAt: -1 }).limit(100);
    const ids = vendors.map(v => v._id);
    const ratings = await Review.aggregate([{ $match: { vendor: { $in: ids } } }, { $group: { _id: '$vendor', avgRating: { $avg: '$rating' }, count: { $sum: 1 } } }]);
    const map = new Map(ratings.map(r => [String(r._id), r]));
    res.json({ vendors: vendors.map(v => ({ ...v.toObject(), rating: map.get(String(v._id))?.avgRating || 0, reviewCount: map.get(String(v._id))?.count || 0 })) });
  } catch (err) { next(err); }
});

router.post('/', protect, allowRoles('vendor', 'admin'), async (req, res, next) => {
  try {
    const { name, category, city, description, priceFrom, imageUrl, contactEmail } = req.body;
    if (!name || !category || !city) return res.status(400).json({ message: 'Name, category and city are required.' });
    const vendor = await Vendor.create({ name, category, city, description, priceFrom, imageUrl, contactEmail, owner: req.user._id });
    res.status(201).json({ vendor });
  } catch (err) { next(err); }
});
module.exports = router;
