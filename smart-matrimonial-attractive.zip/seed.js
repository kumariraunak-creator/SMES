const bcrypt = require('bcryptjs');
const User = require('./models/User');
const Profile = require('./models/Profile');
const Vendor = require('./models/Vendor');

async function seedDatabase() {
  const profileCount = await Profile.countDocuments();
  if (profileCount === 0) {
    const sampleProfiles = [
      { name: 'Aarav Sharma', age: 27, gender: 'Groom', city: 'Delhi NCR', profession: 'Product Designer', education: 'B.Des', about: 'Creative, family-oriented, and always curious about new places.', interests: ['Travel', 'Design', 'Cooking'], photoUrl: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=600&q=80' },
      { name: 'Ananya Rao', age: 25, gender: 'Bride', city: 'Bengaluru', profession: 'Software Engineer', education: 'B.Tech', about: 'Enjoys books, music, weekend hikes, and meaningful conversations.', interests: ['Reading', 'Music', 'Hiking'], photoUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80' },
      { name: 'Rohan Mehta', age: 29, gender: 'Groom', city: 'Delhi NCR', profession: 'Chartered Accountant', education: 'CA', about: 'Balanced, warm, and a fan of fitness and discovering local food.', interests: ['Fitness', 'Food', 'Travel'], photoUrl: 'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=600&q=80' },
      { name: 'Meera Kapoor', age: 26, gender: 'Bride', city: 'Mumbai', profession: 'Architect', education: 'M.Arch', about: 'Loves art, nature, thoughtful design, and home-cooked food.', interests: ['Art', 'Nature', 'Cooking'], photoUrl: 'https://images.unsplash.com/photo-1524504388940-b1c1722653e1?auto=format&fit=crop&w=600&q=80' }
    ];
    for (const p of sampleProfiles) {
      const email = p.name.toLowerCase().replace(/\s+/g, '.') + '@example.demo';
      const user = await User.create({ name: p.name, email, password: await bcrypt.hash(require('crypto').randomBytes(20).toString('hex'), 10) });
      await Profile.create({ ...p, displayName: p.name, user: user._id });
    }
    console.log('🌱 Added sample profiles.');
  }
  if (await Vendor.countDocuments() === 0) {
    await Vendor.insertMany([
      { name: 'The Garden Pavilion', category: 'Venue', city: 'Delhi NCR', description: 'An elegant garden venue for intimate and grand celebrations.', priceFrom: 120000, imageUrl: 'https://images.unsplash.com/photo-1519741497674-611481863552?auto=format&fit=crop&w=900&q=80', contactEmail: 'venues@example.demo' },
      { name: 'Golden Hour Stories', category: 'Photography', city: 'Mumbai', description: 'Candid wedding photography and cinematic films.', priceFrom: 35000, imageUrl: 'https://images.unsplash.com/photo-1511795409834-ef04bbd61622?auto=format&fit=crop&w=900&q=80', contactEmail: 'photo@example.demo' },
      { name: 'Petal & Promise', category: 'Decor', city: 'Bengaluru', description: 'Floral styling, stage design, and personal details.', priceFrom: 50000, imageUrl: 'https://images.unsplash.com/photo-1464366400600-7168b8af9bc3?auto=format&fit=crop&w=900&q=80', contactEmail: 'decor@example.demo' },
      { name: 'Saffron Table', category: 'Catering', city: 'Delhi NCR', description: 'Custom menus and hospitality for your celebration.', priceFrom: 900, imageUrl: 'https://images.unsplash.com/photo-1555244162-803834f70033?auto=format&fit=crop&w=900&q=80', contactEmail: 'food@example.demo' }
    ]);
    console.log('🌱 Added sample wedding vendors.');
  }
}
module.exports = seedDatabase;
